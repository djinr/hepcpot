const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const { auth, isProjectParticipant } = require('../middleware/auth.middleware');
const Payment = require('../models/payment.model');
const Project = require('../models/project.model');
const Contract = require('../models/contract.model');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY || 'sk_test_your_key');

// @route   POST api/payments/deposit
// @desc    Deposit funds to escrow
// @access  Private (Client only)
router.post('/deposit', [
  auth,
  [
    check('projectId', 'Project ID is required').not().isEmpty(),
    check('milestoneId', 'Milestone ID is required').not().isEmpty(),
    check('amount', 'Amount is required').isNumeric(),
    check('paymentMethod', 'Payment method is required').isIn(['credit_card', 'bank_transfer', 'paypal'])
  ]
], async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    const { projectId, milestoneId, amount, paymentMethod } = req.body;

    // Check if user is a client
    if (req.user.userType !== 'client') {
      return res.status(403).json({ success: false, message: 'Only clients can deposit funds' });
    }

    // Get project
    const project = await Project.findById(projectId);
    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }

    // Check if user is the project owner
    if (project.clientId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    // Find milestone
    const milestone = project.milestones.id(milestoneId);
    if (!milestone) {
      return res.status(404).json({ success: false, message: 'Milestone not found' });
    }

    // Get contract
    const contract = await Contract.findById(project.contract.contractId);
    if (!contract) {
      return res.status(404).json({ success: false, message: 'Contract not found' });
    }

    // Calculate platform fee (5% of amount)
    const platformFee = amount * 0.05;
    const totalAmount = amount + platformFee;

    // In a real implementation, we would process the payment with Stripe
    // For now, we'll just create a payment record
    
    // Create payment
    const payment = new Payment({
      projectId,
      contractId: contract._id,
      milestoneId,
      senderId: req.user._id,
      recipientId: project.selectedFreelancer,
      amount,
      platformFee,
      status: 'in_escrow',
      paymentMethod,
      description: `Escrow deposit for milestone: ${milestone.title}`
    });

    await payment.save();

    // Update milestone status
    milestone.status = 'in_progress';
    await project.save();

    res.status(201).json({
      success: true,
      message: 'Funds deposited to escrow successfully',
      payment
    });
  } catch (error) {
    console.error('Deposit funds error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   POST api/payments/release/:milestoneId
// @desc    Release payment for milestone
// @access  Private (Client only)
router.post('/release/:milestoneId', auth, async (req, res) => {
  try {
    // Check if user is a client
    if (req.user.userType !== 'client') {
      return res.status(403).json({ success: false, message: 'Only clients can release payments' });
    }

    const { projectId } = req.body;
    
    // Get project
    const project = await Project.findById(projectId);
    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }

    // Check if user is the project owner
    if (project.clientId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    // Find milestone
    const milestone = project.milestones.id(req.params.milestoneId);
    if (!milestone) {
      return res.status(404).json({ success: false, message: 'Milestone not found' });
    }

    // Check if milestone is submitted
    if (milestone.status !== 'submitted') {
      return res.status(400).json({ success: false, message: 'Milestone must be submitted before releasing payment' });
    }

    // Find payment
    const payment = await Payment.findOne({
      projectId,
      milestoneId: req.params.milestoneId,
      status: 'in_escrow'
    });

    if (!payment) {
      return res.status(404).json({ success: false, message: 'Payment not found' });
    }

    // Update payment status
    payment.status = 'released';
    payment.releaseDate = Date.now();
    await payment.save();

    // Update milestone status
    milestone.status = 'approved';
    milestone.approvalDate = Date.now();
    milestone.isLocked = false;
    await project.save();

    // Check if all milestones are completed
    const allMilestonesCompleted = project.milestones.every(m => m.status === 'approved');
    if (allMilestonesCompleted) {
      project.status = 'completed';
      project.timeline.completionDate = Date.now();
      await project.save();

      // Update contract status
      await Contract.findByIdAndUpdate(
        project.contract.contractId,
        { $set: { status: 'completed' } }
      );
    }

    res.json({
      success: true,
      message: 'Payment released successfully',
      payment
    });
  } catch (error) {
    console.error('Release payment error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   POST api/payments/dispute/:paymentId
// @desc    Dispute payment
// @access  Private (Project participants only)
router.post('/dispute/:paymentId', [
  auth,
  [
    check('reason', 'Reason is required').not().isEmpty()
  ]
], async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    const { reason } = req.body;
    
    // Find payment
    const payment = await Payment.findById(req.params.paymentId);
    if (!payment) {
      return res.status(404).json({ success: false, message: 'Payment not found' });
    }

    // Check if user is a participant
    if (
      payment.senderId.toString() !== req.user._id.toString() &&
      payment.recipientId.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    // Check if payment can be disputed
    if (payment.status !== 'in_escrow') {
      return res.status(400).json({ success: false, message: 'Only payments in escrow can be disputed' });
    }

    // Update payment
    payment.status = 'disputed';
    payment.dispute = {
      isDisputed: true,
      reason,
      status: 'pending'
    };
    
    await payment.save();

    // Get project and update milestone status
    const project = await Project.findById(payment.projectId);
    if (project) {
      const milestone = project.milestones.id(payment.milestoneId);
      if (milestone) {
        milestone.status = 'in_progress';
        await project.save();
      }
    }

    res.json({
      success: true,
      message: 'Payment disputed successfully',
      payment
    });
  } catch (error) {
    console.error('Dispute payment error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   GET api/payments/history
// @desc    Get payment history
// @access  Private
router.get('/history', auth, async (req, res) => {
  try {
    const { status, projectId, limit = 10, page = 1 } = req.query;

    // Build filter object
    const filter = {};
    
    // Filter by user role
    if (req.user.userType === 'client') {
      filter.senderId = req.user._id;
    } else {
      filter.recipientId = req.user._id;
    }

    if (status) filter.status = status;
    if (projectId) filter.projectId = projectId;

    // Calculate pagination
    const skip = (Number(page) - 1) * Number(limit);

    // Get payments
    const payments = await Payment.find(filter)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit))
      .populate('projectId', 'title')
      .populate('senderId', 'name')
      .populate('recipientId', 'name');

    // Get total count
    const total = await Payment.countDocuments(filter);

    res.json({
      success: true,
      payments,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error) {
    console.error('Get payment history error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   POST api/payments/withdraw
// @desc    Withdraw funds
// @access  Private (Freelancer only)
router.post('/withdraw', [
  auth,
  [
    check('amount', 'Amount is required').isNumeric(),
    check('paymentMethod', 'Payment method is required').isIn(['bank_transfer', 'paypal'])
  ]
], async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    // Check if user is a freelancer
    if (req.user.userType !== 'freelancer') {
      return res.status(403).json({ success: false, message: 'Only freelancers can withdraw funds' });
    }

    const { amount, paymentMethod } = req.body;

    // In a real implementation, we would process the withdrawal
    // For now, we'll just return a success message

    res.json({
      success: true,
      message: 'Withdrawal request submitted successfully',
      withdrawal: {
        amount,
        paymentMethod,
        status: 'processing',
        date: Date.now()
      }
    });
  } catch (error) {
    console.error('Withdraw funds error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
