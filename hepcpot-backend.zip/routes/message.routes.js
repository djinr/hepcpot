const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const { auth } = require('../middleware/auth.middleware');
const Message = require('../models/message.model');
const User = require('../models/user.model');

// @route   POST api/messages
// @desc    Send a message
// @access  Private
router.post('/', [
  auth,
  [
    check('recipientId', 'Recipient ID is required').not().isEmpty(),
    check('content', 'Message content is required').not().isEmpty(),
    check('projectId', 'Project ID is required for project messages').optional()
  ]
], async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    const { recipientId, content, projectId, attachments } = req.body;

    // Check if recipient exists
    const recipient = await User.findById(recipientId);
    if (!recipient) {
      return res.status(404).json({ success: false, message: 'Recipient not found' });
    }

    // Create conversation ID (sorted user IDs joined with a hyphen)
    const participants = [req.user._id.toString(), recipientId].sort();
    const conversationId = participants.join('-');

    // Create new message
    const message = new Message({
      conversationId,
      senderId: req.user._id,
      recipientId,
      projectId,
      content,
      attachments: attachments || [],
      type: attachments && attachments.length > 0 ? 'file' : 'text'
    });

    await message.save();

    res.status(201).json({
      success: true,
      message
    });
  } catch (error) {
    console.error('Send message error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   GET api/messages/conversations
// @desc    Get all conversations for a user
// @access  Private
router.get('/conversations', auth, async (req, res) => {
  try {
    // Find all messages where user is either sender or recipient
    const messages = await Message.find({
      $or: [
        { senderId: req.user._id },
        { recipientId: req.user._id }
      ]
    }).sort({ createdAt: -1 });

    // Extract unique conversation IDs
    const conversationIds = [...new Set(messages.map(message => message.conversationId))];

    // Get latest message and other user for each conversation
    const conversations = await Promise.all(conversationIds.map(async (conversationId) => {
      const latestMessage = await Message.findOne({ conversationId })
        .sort({ createdAt: -1 });

      // Get other user ID
      const otherUserId = conversationId.split('-').find(id => id !== req.user._id.toString());
      
      // Get other user details
      const otherUser = await User.findById(otherUserId).select('name profilePicture userType');

      // Count unread messages
      const unreadCount = await Message.countDocuments({
        conversationId,
        recipientId: req.user._id,
        isRead: false
      });

      return {
        conversationId,
        otherUser,
        latestMessage,
        unreadCount,
        projectId: latestMessage.projectId
      };
    }));

    res.json({
      success: true,
      conversations
    });
  } catch (error) {
    console.error('Get conversations error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   GET api/messages/conversation/:userId
// @desc    Get messages between current user and specified user
// @access  Private
router.get('/conversation/:userId', auth, async (req, res) => {
  try {
    const otherUserId = req.params.userId;
    
    // Create conversation ID (sorted user IDs joined with a hyphen)
    const participants = [req.user._id.toString(), otherUserId].sort();
    const conversationId = participants.join('-');

    // Get messages
    const messages = await Message.find({ conversationId })
      .sort({ createdAt: 1 })
      .populate('senderId', 'name profilePicture')
      .populate('recipientId', 'name profilePicture');

    // Mark messages as read
    await Message.updateMany(
      {
        conversationId,
        recipientId: req.user._id,
        isRead: false
      },
      { $set: { isRead: true } }
    );

    res.json({
      success: true,
      messages
    });
  } catch (error) {
    console.error('Get conversation error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   GET api/messages/project/:projectId
// @desc    Get messages for a specific project
// @access  Private
router.get('/project/:projectId', auth, async (req, res) => {
  try {
    // Get messages
    const messages = await Message.find({ projectId: req.params.projectId })
      .sort({ createdAt: 1 })
      .populate('senderId', 'name profilePicture userType')
      .populate('recipientId', 'name profilePicture userType');

    // Mark messages as read
    await Message.updateMany(
      {
        projectId: req.params.projectId,
        recipientId: req.user._id,
        isRead: false
      },
      { $set: { isRead: true } }
    );

    res.json({
      success: true,
      messages
    });
  } catch (error) {
    console.error('Get project messages error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   PUT api/messages/read/:messageId
// @desc    Mark message as read
// @access  Private
router.put('/read/:messageId', auth, async (req, res) => {
  try {
    const message = await Message.findById(req.params.messageId);
    
    if (!message) {
      return res.status(404).json({ success: false, message: 'Message not found' });
    }
    
    // Check if user is the recipient
    if (message.recipientId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }
    
    // Mark as read
    message.isRead = true;
    await message.save();
    
    res.json({
      success: true,
      message
    });
  } catch (error) {
    console.error('Mark message as read error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Message not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   DELETE api/messages/:messageId
// @desc    Delete message
// @access  Private
router.delete('/:messageId', auth, async (req, res) => {
  try {
    const message = await Message.findById(req.params.messageId);
    
    if (!message) {
      return res.status(404).json({ success: false, message: 'Message not found' });
    }
    
    // Check if user is the sender
    if (message.senderId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }
    
    // Delete message
    await Message.findByIdAndDelete(req.params.messageId);
    
    res.json({
      success: true,
      message: 'Message deleted'
    });
  } catch (error) {
    console.error('Delete message error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Message not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
