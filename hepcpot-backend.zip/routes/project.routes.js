const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const { auth, isClient } = require('../middleware/auth.middleware');
const Project = require('../models/project.model');
const User = require('../models/user.model');
const Contract = require('../models/contract.model');

// @route   POST api/projects
// @desc    Create a new project
// @access  Private (Client only)
router.post('/', [
  auth, 
  isClient,
  [
    check('title', 'Title is required').not().isEmpty(),
    check('description', 'Description is required').not().isEmpty(),
    check('category', 'Category is required').not().isEmpty(),
    check('budget.minAmount', 'Minimum budget amount is required').isNumeric(),
    check('budget.maxAmount', 'Maximum budget amount is required').isNumeric(),
    check('timeline.deadline', 'Deadline is required').not().isEmpty()
  ]
], async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    const {
      title,
      description,
      category,
      subcategory,
      budget,
      timeline,
      attachments
    } = req.body;

    // Create new project
    const project = new Project({
      title,
      description,
      clientId: req.user._id,
      category,
      subcategory,
      budget,
      timeline: {
        ...timeline,
        postedDate: Date.now()
      },
      attachments
    });

    // Save project to database
    await project.save();

    // Update client's posted projects
    await User.findByIdAndUpdate(
      req.user._id,
      { $push: { 'clientProfile.postedProjects': project._id } }
    );

    res.status(201).json({
      success: true,
      project
    });
  } catch (error) {
    console.error('Create project error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   GET api/projects
// @desc    Get all projects with filters
// @access  Public
router.get('/', async (req, res) => {
  try {
    const {
      category,
      status,
      minBudget,
      maxBudget,
      search,
      limit = 10,
      page = 1
    } = req.query;

    // Build filter object
    const filter = {};
    
    if (category) filter.category = category;
    if (status) filter.status = status;
    if (minBudget) filter['budget.minAmount'] = { $gte: Number(minBudget) };
    if (maxBudget) filter['budget.maxAmount'] = { $lte: Number(maxBudget) };
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }

    // Calculate pagination
    const skip = (Number(page) - 1) * Number(limit);

    // Get projects
    const projects = await Project.find(filter)
      .sort({ 'timeline.postedDate': -1 })
      .skip(skip)
      .limit(Number(limit))
      .populate('clientId', 'name profilePicture clientProfile.rating')
      .populate('selectedFreelancer', 'name profilePicture freelancerProfile.rating');

    // Get total count
    const total = await Project.countDocuments(filter);

    res.json({
      success: true,
      projects,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error) {
    console.error('Get projects error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   GET api/projects/:id
// @desc    Get project by ID
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const project = await Project.findById(req.params.id)
      .populate('clientId', 'name profilePicture clientProfile')
      .populate('selectedFreelancer', 'name profilePicture freelancerProfile')
      .populate('proposals.freelancerId', 'name profilePicture freelancerProfile.rating');

    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }

    res.json({
      success: true,
      project
    });
  } catch (error) {
    console.error('Get project error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   PUT api/projects/:id
// @desc    Update project
// @access  Private (Client only)
router.put('/:id', [auth, isClient], async (req, res) => {
  try {
    let project = await Project.findById(req.params.id);

    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }

    // Check if user is the project owner
    if (project.clientId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    // Check if project can be updated
    if (project.status !== 'open') {
      return res.status(400).json({ success: false, message: 'Project cannot be updated once it has started' });
    }

    const {
      title,
      description,
      category,
      subcategory,
      budget,
      timeline,
      attachments
    } = req.body;

    // Update project
    project = await Project.findByIdAndUpdate(
      req.params.id,
      {
        $set: {
          title: title || project.title,
          description: description || project.description,
          category: category || project.category,
          subcategory: subcategory || project.subcategory,
          budget: budget || project.budget,
          timeline: timeline || project.timeline,
          attachments: attachments || project.attachments
        }
      },
      { new: true }
    );

    res.json({
      success: true,
      project
    });
  } catch (error) {
    console.error('Update project error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   DELETE api/projects/:id
// @desc    Delete project
// @access  Private (Client only)
router.delete('/:id', [auth, isClient], async (req, res) => {
  try {
    const project = await Project.findById(req.params.id);

    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }

    // Check if user is the project owner
    if (project.clientId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    // Check if project can be deleted
    if (project.status !== 'open') {
      return res.status(400).json({ success: false, message: 'Project cannot be deleted once it has started' });
    }

    // Delete project
    await Project.findByIdAndDelete(req.params.id);

    // Update client's posted projects
    await User.findByIdAndUpdate(
      req.user._id,
      { $pull: { 'clientProfile.postedProjects': req.params.id } }
    );

    res.json({
      success: true,
      message: 'Project deleted'
    });
  } catch (error) {
    console.error('Delete project error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   POST api/projects/:id/proposals
// @desc    Submit a proposal for a project
// @access  Private (Freelancer only)
router.post('/:id/proposals', [
  auth,
  [
    check('proposalText', 'Proposal text is required').not().isEmpty(),
    check('bidAmount', 'Bid amount is required').isNumeric(),
    check('estimatedTime', 'Estimated time is required').not().isEmpty()
  ]
], async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    // Check if user is a freelancer
    if (req.user.userType !== 'freelancer') {
      return res.status(403).json({ success: false, message: 'Only freelancers can submit proposals' });
    }

    const project = await Project.findById(req.params.id);

    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }

    // Check if project is open for proposals
    if (project.status !== 'open') {
      return res.status(400).json({ success: false, message: 'Project is not open for proposals' });
    }

    // Check if freelancer has already submitted a proposal
    const existingProposal = project.proposals.find(
      proposal => proposal.freelancerId.toString() === req.user._id.toString()
    );

    if (existingProposal) {
      return res.status(400).json({ success: false, message: 'You have already submitted a proposal for this project' });
    }

    const { proposalText, bidAmount, estimatedTime } = req.body;

    // Create new proposal
    const proposal = {
      freelancerId: req.user._id,
      proposalText,
      bidAmount,
      estimatedTime,
      submissionDate: Date.now()
    };

    // Add proposal to project
    project.proposals.push(proposal);
    await project.save();

    res.status(201).json({
      success: true,
      proposal
    });
  } catch (error) {
    console.error('Submit proposal error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   GET api/projects/:id/proposals
// @desc    Get all proposals for a project
// @access  Private (Project owner only)
router.get('/:id/proposals', auth, async (req, res) => {
  try {
    const project = await Project.findById(req.params.id);

    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }

    // Check if user is the project owner
    if (project.clientId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    // Populate freelancer details
    await Project.populate(project, {
      path: 'proposals.freelancerId',
      select: 'name profilePicture freelancerProfile.skills freelancerProfile.rating'
    });

    res.json({
      success: true,
      proposals: project.proposals
    });
  } catch (error) {
    console.error('Get proposals error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   POST api/projects/:id/hire
// @desc    Hire a freelancer for a project
// @access  Private (Client only)
router.post('/:id/hire', [
  auth,
  isClient,
  [
    check('freelancerId', 'Freelancer ID is required').not().isEmpty(),
    check('proposalId', 'Proposal ID is required').not().isEmpty()
  ]
], async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    const { freelancerId, proposalId } = req.body;

    const project = await Project.findById(req.params.id);

    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }

    // Check if user is the project owner
    if (project.clientId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    // Check if project is open
    if (project.status !== 'open') {
      return res.status(400).json({ success: false, message: 'Project is not open for hiring' });
    }

    // Find the proposal
    const proposal = project.proposals.id(proposalId);

    if (!proposal) {
      return res.status(404).json({ success: false, message: 'Proposal not found' });
    }

    // Check if the freelancer ID matches the proposal
    if (proposal.freelancerId.toString() !== freelancerId) {
      return res.status(400).json({ success: false, message: 'Freelancer ID does not match proposal' });
    }

    // Update project status and selected freelancer
    project.status = 'in_progress';
    project.selectedFreelancer = freelancerId;
    
    // Update proposal status
    proposal.status = 'accepted';
    
    // Set other proposals to rejected
    project.proposals.forEach(p => {
      if (p._id.toString() !== proposalId) {
        p.status = 'rejected';
      }
    });

    // Save project
    await project.save();

    // Create a contract
    const contract = new Contract({
      projectId: project._id,
      clientId: req.user._id,
      freelancerId,
      title: `Contract for ${project.title}`,
      description: project.description,
      terms: 'Standard terms and conditions apply.',
      scope: project.description,
      deliverables: ['Complete project as described'],
      timeline: {
        startDate: Date.now(),
        endDate: project.timeline.deadline,
        milestones: [{
          title: 'Project Completion',
          dueDate: project.timeline.deadline
        }]
      },
      payment: {
        amount: proposal.bidAmount,
        type: project.budget.type,
        currency: 'USD',
        milestones: [{
          title: 'Project Completion',
          amount: proposal.bidAmount,
          releaseCondition: 'Upon client approval of deliverables'
        }]
      }
    });

    // Save contract
    await contract.save();

    // Update project with contract ID
    project.contract.contractId = contract._id;
    await project.save();

    res.json({
      success: true,
      message: 'Freelancer hired successfully',
      project,
      contract
    });
  } catch (error) {
    console.error('Hire freelancer error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Project or proposal not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
