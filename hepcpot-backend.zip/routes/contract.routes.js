const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const { auth, isProjectParticipant } = require('../middleware/auth.middleware');
const Contract = require('../models/contract.model');
const Project = require('../models/project.model');

// @route   GET api/contracts/:id
// @desc    Get contract by ID
// @access  Private (Project participants only)
router.get('/:id', auth, async (req, res) => {
  try {
    const contract = await Contract.findById(req.params.id)
      .populate('clientId', 'name email profilePicture')
      .populate('freelancerId', 'name email profilePicture');

    if (!contract) {
      return res.status(404).json({ success: false, message: 'Contract not found' });
    }

    // Check if user is a participant in the contract
    if (
      contract.clientId._id.toString() !== req.user._id.toString() &&
      contract.freelancerId._id.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({ success: false, message: 'Not authorized to view this contract' });
    }

    res.json({
      success: true,
      contract
    });
  } catch (error) {
    console.error('Get contract error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Contract not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   PUT api/contracts/:id
// @desc    Update contract
// @access  Private (Project participants only)
router.put('/:id', [
  auth,
  [
    check('terms', 'Terms are required').optional(),
    check('scope', 'Scope is required').optional(),
    check('deliverables', 'Deliverables must be an array').optional().isArray(),
    check('timeline', 'Timeline must be an object').optional().isObject(),
    check('payment', 'Payment must be an object').optional().isObject()
  ]
], async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    let contract = await Contract.findById(req.params.id);

    if (!contract) {
      return res.status(404).json({ success: false, message: 'Contract not found' });
    }

    // Check if user is a participant in the contract
    if (
      contract.clientId.toString() !== req.user._id.toString() &&
      contract.freelancerId.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({ success: false, message: 'Not authorized to update this contract' });
    }

    // Check if contract can be updated
    if (contract.status !== 'draft') {
      return res.status(400).json({ success: false, message: 'Contract cannot be updated once it has been signed' });
    }

    const {
      terms,
      scope,
      deliverables,
      timeline,
      payment
    } = req.body;

    // Update contract
    contract = await Contract.findByIdAndUpdate(
      req.params.id,
      {
        $set: {
          terms: terms || contract.terms,
          scope: scope || contract.scope,
          deliverables: deliverables || contract.deliverables,
          timeline: timeline || contract.timeline,
          payment: payment || contract.payment,
          lastUpdated: Date.now()
        }
      },
      { new: true }
    );

    res.json({
      success: true,
      contract
    });
  } catch (error) {
    console.error('Update contract error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Contract not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   POST api/contracts/:id/sign
// @desc    Sign contract
// @access  Private (Project participants only)
router.post('/:id/sign', auth, async (req, res) => {
  try {
    const contract = await Contract.findById(req.params.id);

    if (!contract) {
      return res.status(404).json({ success: false, message: 'Contract not found' });
    }

    // Check if user is a participant in the contract
    const isClient = contract.clientId.toString() === req.user._id.toString();
    const isFreelancer = contract.freelancerId.toString() === req.user._id.toString();

    if (!isClient && !isFreelancer) {
      return res.status(403).json({ success: false, message: 'Not authorized to sign this contract' });
    }

    // Update signature based on user role
    if (isClient) {
      contract.signatures.client.signed = true;
      contract.signatures.client.date = Date.now();
    } else {
      contract.signatures.freelancer.signed = true;
      contract.signatures.freelancer.date = Date.now();
    }

    // Check if both parties have signed
    if (contract.signatures.client.signed && contract.signatures.freelancer.signed) {
      contract.status = 'active';
      
      // Update project contract status
      await Project.findByIdAndUpdate(
        contract.projectId,
        {
          $set: {
            'contract.signedByClient': true,
            'contract.signedByFreelancer': true,
            'contract.signatureDate': Date.now()
          }
        }
      );
    }

    await contract.save();

    res.json({
      success: true,
      message: 'Contract signed successfully',
      contract
    });
  } catch (error) {
    console.error('Sign contract error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Contract not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   POST api/contracts/:id/terminate
// @desc    Terminate contract
// @access  Private (Project participants only)
router.post('/:id/terminate', [
  auth,
  [
    check('reason', 'Reason is required').not().isEmpty()
  ]
], async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    const { reason } = req.body;
    
    const contract = await Contract.findById(req.params.id);

    if (!contract) {
      return res.status(404).json({ success: false, message: 'Contract not found' });
    }

    // Check if user is a participant in the contract
    if (
      contract.clientId.toString() !== req.user._id.toString() &&
      contract.freelancerId.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({ success: false, message: 'Not authorized to terminate this contract' });
    }

    // Check if contract can be terminated
    if (contract.status !== 'active') {
      return res.status(400).json({ success: false, message: 'Only active contracts can be terminated' });
    }

    // Update contract status
    contract.status = 'terminated';
    contract.terminationReason = reason;
    contract.terminatedBy = req.user._id;
    contract.terminationDate = Date.now();
    
    await contract.save();

    // Update project status
    await Project.findByIdAndUpdate(
      contract.projectId,
      { $set: { status: 'cancelled' } }
    );

    res.json({
      success: true,
      message: 'Contract terminated successfully',
      contract
    });
  } catch (error) {
    console.error('Terminate contract error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Contract not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
