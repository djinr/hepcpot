const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const { auth } = require('../middleware/auth.middleware');
const User = require('../models/user.model');
const Project = require('../models/project.model');
const Review = require('../models/review.model');

// @route   GET api/users/profile
// @desc    Get current user's profile
// @access  Private
router.get('/profile', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .select('-password')
      .populate({
        path: 'freelancerProfile.portfolio',
        select: 'title description category status'
      })
      .populate({
        path: 'clientProfile.postedProjects',
        select: 'title description category status'
      });

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    res.json({
      success: true,
      user
    });
  } catch (error) {
    console.error('Get profile error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   PUT api/users/profile
// @desc    Update user profile
// @access  Private
router.put('/profile', [
  auth,
  [
    check('name', 'Name is required').optional().not().isEmpty(),
    check('email', 'Please include a valid email').optional().isEmail(),
    check('contactInfo', 'Contact info must be an object').optional().isObject(),
    check('freelancerProfile', 'Freelancer profile must be an object').optional().isObject(),
    check('clientProfile', 'Client profile must be an object').optional().isObject()
  ]
], async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    const {
      name,
      email,
      profilePicture,
      contactInfo,
      freelancerProfile,
      clientProfile
    } = req.body;

    // Build profile update object
    const profileFields = {};
    if (name) profileFields.name = name;
    if (email) profileFields.email = email;
    if (profilePicture) profileFields.profilePicture = profilePicture;
    if (contactInfo) profileFields.contactInfo = contactInfo;

    // Update user type specific fields
    if (req.user.userType === 'freelancer' && freelancerProfile) {
      profileFields.freelancerProfile = {
        ...req.user.freelancerProfile,
        ...freelancerProfile
      };
    }

    if (req.user.userType === 'client' && clientProfile) {
      profileFields.clientProfile = {
        ...req.user.clientProfile,
        ...clientProfile
      };
    }

    // Update user
    const user = await User.findByIdAndUpdate(
      req.user._id,
      { $set: profileFields },
      { new: true }
    ).select('-password');

    res.json({
      success: true,
      user
    });
  } catch (error) {
    console.error('Update profile error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   GET api/users/freelancers
// @desc    Get all freelancers with filters
// @access  Public
router.get('/freelancers', async (req, res) => {
  try {
    const {
      skills,
      rating,
      availability,
      search,
      limit = 10,
      page = 1
    } = req.query;

    // Build filter object
    const filter = { userType: 'freelancer' };
    
    if (skills) {
      const skillsArray = skills.split(',');
      filter['freelancerProfile.skills'] = { $in: skillsArray };
    }
    
    if (rating) {
      filter['freelancerProfile.rating'] = { $gte: Number(rating) };
    }
    
    if (availability) {
      filter['freelancerProfile.availability'] = availability;
    }
    
    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { 'freelancerProfile.skills': { $regex: search, $options: 'i' } }
      ];
    }

    // Calculate pagination
    const skip = (Number(page) - 1) * Number(limit);

    // Get freelancers
    const freelancers = await User.find(filter)
      .select('name profilePicture freelancerProfile')
      .sort({ 'freelancerProfile.rating': -1 })
      .skip(skip)
      .limit(Number(limit));

    // Get total count
    const total = await User.countDocuments(filter);

    res.json({
      success: true,
      freelancers,
      pagination: {
        total,
        page: Number(page),
        limit: Number(limit),
        pages: Math.ceil(total / Number(limit))
      }
    });
  } catch (error) {
    console.error('Get freelancers error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   GET api/users/:id
// @desc    Get user by ID
// @access  Public
router.get('/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id)
      .select('-password -paymentInfo')
      .populate({
        path: 'freelancerProfile.portfolio',
        select: 'title description category status'
      })
      .populate({
        path: 'clientProfile.postedProjects',
        select: 'title description category status'
      });

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    // Get reviews
    const reviews = await Review.find({ receiverId: req.params.id })
      .populate('reviewerId', 'name profilePicture')
      .populate('projectId', 'title');

    res.json({
      success: true,
      user,
      reviews
    });
  } catch (error) {
    console.error('Get user error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   POST api/users/payment-methods
// @desc    Add payment method
// @access  Private
router.post('/payment-methods', [
  auth,
  [
    check('type', 'Payment method type is required').isIn(['card', 'bank_account', 'paypal']),
    check('details', 'Payment method details are required').isObject()
  ]
], async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    const { type, details, isDefault } = req.body;

    const user = await User.findById(req.user._id);

    // Create payment method
    const paymentMethod = {
      type,
      details,
      isDefault: isDefault || false
    };

    // If this is the first payment method or isDefault is true, set all others to false
    if (isDefault || user.paymentInfo.paymentMethods.length === 0) {
      user.paymentInfo.paymentMethods.forEach(method => {
        method.isDefault = false;
      });
      paymentMethod.isDefault = true;
    }

    // Add payment method
    user.paymentInfo.paymentMethods.push(paymentMethod);
    await user.save();

    res.status(201).json({
      success: true,
      paymentMethods: user.paymentInfo.paymentMethods
    });
  } catch (error) {
    console.error('Add payment method error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   POST api/users/reviews
// @desc    Create a review
// @access  Private
router.post('/reviews', [
  auth,
  [
    check('projectId', 'Project ID is required').not().isEmpty(),
    check('receiverId', 'Receiver ID is required').not().isEmpty(),
    check('rating', 'Rating must be between 1 and 5').isInt({ min: 1, max: 5 }),
    check('comment', 'Comment is required').not().isEmpty(),
    check('reviewType', 'Review type is required').isIn(['client_to_freelancer', 'freelancer_to_client'])
  ]
], async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }

  try {
    const { projectId, receiverId, rating, comment, reviewType, isPublic } = req.body;

    // Check if project exists
    const project = await Project.findById(projectId);
    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }

    // Check if user is a participant in the project
    const isClient = project.clientId.toString() === req.user._id.toString();
    const isFreelancer = project.selectedFreelancer && project.selectedFreelancer.toString() === req.user._id.toString();

    if (!isClient && !isFreelancer) {
      return res.status(403).json({ success: false, message: 'Not authorized to review this project' });
    }

    // Check if review type matches user role
    if ((reviewType === 'client_to_freelancer' && !isClient) || 
        (reviewType === 'freelancer_to_client' && !isFreelancer)) {
      return res.status(400).json({ success: false, message: 'Review type does not match user role' });
    }

    // Check if user has already reviewed this project
    const existingReview = await Review.findOne({
      projectId,
      reviewerId: req.user._id
    });

    if (existingReview) {
      return res.status(400).json({ success: false, message: 'You have already reviewed this project' });
    }

    // Create review
    const review = new Review({
      projectId,
      reviewerId: req.user._id,
      receiverId,
      rating,
      comment,
      reviewType,
      isPublic: isPublic !== undefined ? isPublic : true
    });

    await review.save();

    // Update project reviews
    if (reviewType === 'client_to_freelancer') {
      project.reviews.clientReview = {
        rating,
        comment,
        date: Date.now()
      };
    } else {
      project.reviews.freelancerReview = {
        rating,
        comment,
        date: Date.now()
      };
    }

    await project.save();

    // Update user rating
    const receiver = await User.findById(receiverId);
    
    if (reviewType === 'client_to_freelancer') {
      // Get all freelancer reviews
      const freelancerReviews = await Review.find({
        receiverId,
        reviewType: 'client_to_freelancer'
      });
      
      // Calculate average rating
      const totalRating = freelancerReviews.reduce((sum, review) => sum + review.rating, 0);
      const averageRating = totalRating / freelancerReviews.length;
      
      // Update freelancer rating
      receiver.freelancerProfile.rating = averageRating;
      receiver.freelancerProfile.reviews.push(review._id);
    } else {
      // Get all client reviews
      const clientReviews = await Review.find({
        receiverId,
        reviewType: 'freelancer_to_client'
      });
      
      // Calculate average rating
      const totalRating = clientReviews.reduce((sum, review) => sum + review.rating, 0);
      const averageRating = totalRating / clientReviews.length;
      
      // Update client rating
      receiver.clientProfile.rating = averageRating;
      receiver.clientProfile.reviews.push(review._id);
    }
    
    await receiver.save();

    res.status(201).json({
      success: true,
      review
    });
  } catch (error) {
    console.error('Create review error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
