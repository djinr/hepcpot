const express = require('express');
const router = express.Router();
const { check, validationResult } = require('express-validator');
const { auth, isProjectParticipant } = require('../middleware/auth.middleware');
const Project = require('../models/project.model');
const { v4: uuidv4 } = require('uuid');

// @route   GET api/moodboards/:projectId
// @desc    Get moodboard for a project
// @access  Private (Project participants only)
router.get('/:projectId', auth, async (req, res) => {
  try {
    const project = await Project.findById(req.params.projectId);
    
    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
    
    // Check if user is a participant
    const isClient = project.clientId.toString() === req.user._id.toString();
    const isFreelancer = project.selectedFreelancer && project.selectedFreelancer.toString() === req.user._id.toString();
    
    if (!isClient && !isFreelancer && !project.moodboard.isPublic) {
      return res.status(403).json({ success: false, message: 'Not authorized to view this moodboard' });
    }
    
    res.json({
      success: true,
      moodboard: project.moodboard
    });
  } catch (error) {
    console.error('Get moodboard error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   POST api/moodboards/:projectId/elements
// @desc    Add element to moodboard
// @access  Private (Project participants only)
router.post('/:projectId/elements', [
  auth,
  [
    check('type', 'Type is required').isIn(['image', 'text', 'color']),
    check('content', 'Content is required').not().isEmpty(),
    check('notes', 'Notes must be a string').optional().isString()
  ]
], async (req, res) => {
  // Check for validation errors
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, errors: errors.array() });
  }
  
  try {
    const project = await Project.findById(req.params.projectId);
    
    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
    
    // Check if user is a participant
    const isClient = project.clientId.toString() === req.user._id.toString();
    const isFreelancer = project.selectedFreelancer && project.selectedFreelancer.toString() === req.user._id.toString();
    
    if (!isClient && !isFreelancer) {
      return res.status(403).json({ success: false, message: 'Not authorized to modify this moodboard' });
    }
    
    const { type, content, notes } = req.body;
    
    // Create new element
    const newElement = {
      type,
      content,
      notes,
      addedBy: req.user._id,
      addedDate: Date.now()
    };
    
    // Add element to moodboard
    if (!project.moodboard) {
      project.moodboard = {
        elements: [newElement],
        isPublic: false
      };
    } else {
      project.moodboard.elements.push(newElement);
    }
    
    await project.save();
    
    res.status(201).json({
      success: true,
      element: newElement,
      moodboard: project.moodboard
    });
  } catch (error) {
    console.error('Add moodboard element error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   DELETE api/moodboards/:projectId/elements/:elementId
// @desc    Remove element from moodboard
// @access  Private (Project participants only)
router.delete('/:projectId/elements/:elementId', auth, async (req, res) => {
  try {
    const project = await Project.findById(req.params.projectId);
    
    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
    
    // Check if user is a participant
    const isClient = project.clientId.toString() === req.user._id.toString();
    const isFreelancer = project.selectedFreelancer && project.selectedFreelancer.toString() === req.user._id.toString();
    
    if (!isClient && !isFreelancer) {
      return res.status(403).json({ success: false, message: 'Not authorized to modify this moodboard' });
    }
    
    // Find element index
    const elementIndex = project.moodboard.elements.findIndex(
      element => element._id.toString() === req.params.elementId
    );
    
    if (elementIndex === -1) {
      return res.status(404).json({ success: false, message: 'Element not found' });
    }
    
    // Check if user is the one who added the element or is the client
    const element = project.moodboard.elements[elementIndex];
    if (element.addedBy.toString() !== req.user._id.toString() && !isClient) {
      return res.status(403).json({ success: false, message: 'Not authorized to remove this element' });
    }
    
    // Remove element
    project.moodboard.elements.splice(elementIndex, 1);
    await project.save();
    
    res.json({
      success: true,
      message: 'Element removed successfully',
      moodboard: project.moodboard
    });
  } catch (error) {
    console.error('Remove moodboard element error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Project or element not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// @route   PUT api/moodboards/:projectId/share
// @desc    Generate or update shareable link for moodboard
// @access  Private (Project participants only)
router.put('/:projectId/share', auth, async (req, res) => {
  try {
    const project = await Project.findById(req.params.projectId);
    
    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
    
    // Check if user is a participant
    const isClient = project.clientId.toString() === req.user._id.toString();
    const isFreelancer = project.selectedFreelancer && project.selectedFreelancer.toString() === req.user._id.toString();
    
    if (!isClient && !isFreelancer) {
      return res.status(403).json({ success: false, message: 'Not authorized to share this moodboard' });
    }
    
    // Generate shareable link if it doesn't exist
    if (!project.moodboard.shareableLink) {
      project.moodboard.shareableLink = `moodboard-${uuidv4()}`;
    }
    
    // Update public status
    project.moodboard.isPublic = req.body.isPublic !== undefined ? req.body.isPublic : true;
    
    await project.save();
    
    res.json({
      success: true,
      shareableLink: project.moodboard.shareableLink,
      isPublic: project.moodboard.isPublic
    });
  } catch (error) {
    console.error('Share moodboard error:', error.message);
    if (error.kind === 'ObjectId') {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
