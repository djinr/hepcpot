const mongoose = require('mongoose');

const ProjectSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  clientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  category: {
    type: String,
    required: true,
    enum: ['graphic_design', 'web_design', 'logo_design', 'branding', 'illustration', 'packaging', 'social_media', 'other']
  },
  subcategory: {
    type: String,
    default: ''
  },
  status: {
    type: String,
    enum: ['open', 'in_progress', 'review', 'completed', 'cancelled'],
    default: 'open'
  },
  budget: {
    minAmount: {
      type: Number,
      required: true
    },
    maxAmount: {
      type: Number,
      required: true
    },
    type: {
      type: String,
      enum: ['hourly', 'fixed'],
      default: 'fixed'
    }
  },
  timeline: {
    postedDate: {
      type: Date,
      default: Date.now
    },
    deadline: {
      type: Date,
      required: true
    },
    startDate: {
      type: Date
    },
    completionDate: {
      type: Date
    }
  },
  attachments: [{
    type: String
  }],
  proposals: [{
    freelancerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    proposalText: {
      type: String,
      required: true
    },
    bidAmount: {
      type: Number,
      required: true
    },
    estimatedTime: {
      type: String,
      required: true
    },
    status: {
      type: String,
      enum: ['pending', 'accepted', 'rejected'],
      default: 'pending'
    },
    submissionDate: {
      type: Date,
      default: Date.now
    }
  }],
  selectedFreelancer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  contract: {
    contractId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Contract'
    },
    terms: {
      type: String
    },
    signedByClient: {
      type: Boolean,
      default: false
    },
    signedByFreelancer: {
      type: Boolean,
      default: false
    },
    signatureDate: {
      type: Date
    }
  },
  milestones: [{
    title: {
      type: String,
      required: true
    },
    description: {
      type: String,
      required: true
    },
    amount: {
      type: Number,
      required: true
    },
    dueDate: {
      type: Date,
      required: true
    },
    status: {
      type: String,
      enum: ['pending', 'in_progress', 'submitted', 'approved', 'rejected'],
      default: 'pending'
    },
    submissionDate: {
      type: Date
    },
    approvalDate: {
      type: Date
    },
    deliverables: [{
      type: String
    }],
    feedback: {
      type: String
    },
    isLocked: {
      type: Boolean,
      default: true
    },
    unlockDate: {
      type: Date
    }
  }],
  moodboard: {
    elements: [{
      type: {
        type: String,
        enum: ['image', 'text', 'color'],
        required: true
      },
      content: {
        type: String,
        required: true
      },
      notes: {
        type: String
      },
      addedBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
      },
      addedDate: {
        type: Date,
        default: Date.now
      }
    }],
    isPublic: {
      type: Boolean,
      default: false
    },
    shareableLink: {
      type: String
    }
  },
  messages: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Message'
  }],
  reviews: {
    clientReview: {
      rating: {
        type: Number,
        min: 1,
        max: 5
      },
      comment: {
        type: String
      },
      date: {
        type: Date
      }
    },
    freelancerReview: {
      rating: {
        type: Number,
        min: 1,
        max: 5
      },
      comment: {
        type: String
      },
      date: {
        type: Date
      }
    }
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Project', ProjectSchema);
