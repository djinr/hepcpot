const mongoose = require('mongoose');

const ContractSchema = new mongoose.Schema({
  projectId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Project',
    required: true
  },
  clientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  freelancerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  terms: {
    type: String,
    required: true
  },
  scope: {
    type: String,
    required: true
  },
  deliverables: [{
    type: String,
    required: true
  }],
  timeline: {
    startDate: {
      type: Date,
      required: true
    },
    endDate: {
      type: Date,
      required: true
    },
    milestones: [{
      title: {
        type: String,
        required: true
      },
      dueDate: {
        type: Date,
        required: true
      }
    }]
  },
  payment: {
    amount: {
      type: Number,
      required: true
    },
    type: {
      type: String,
      enum: ['hourly', 'fixed'],
      default: 'fixed'
    },
    rate: {
      type: Number
    },
    currency: {
      type: String,
      default: 'USD'
    },
    milestones: [{
      title: {
        type: String,
        required: true
      },
      amount: {
        type: Number,
        required: true
      },
      releaseCondition: {
        type: String,
        required: true
      }
    }]
  },
  signatures: {
    client: {
      signed: {
        type: Boolean,
        default: false
      },
      date: {
        type: Date
      }
    },
    freelancer: {
      signed: {
        type: Boolean,
        default: false
      },
      date: {
        type: Date
      }
    }
  },
  status: {
    type: String,
    enum: ['draft', 'active', 'completed', 'terminated'],
    default: 'draft'
  },
  creationDate: {
    type: Date,
    default: Date.now
  },
  lastUpdated: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Contract', ContractSchema);
