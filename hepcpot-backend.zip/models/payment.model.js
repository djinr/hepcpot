const mongoose = require('mongoose');

const PaymentSchema = new mongoose.Schema({
  projectId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Project',
    required: true
  },
  contractId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Contract',
    required: true
  },
  milestoneId: {
    type: mongoose.Schema.Types.ObjectId
  },
  senderId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  recipientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  amount: {
    type: Number,
    required: true
  },
  currency: {
    type: String,
    default: 'USD'
  },
  platformFee: {
    type: Number,
    required: true
  },
  status: {
    type: String,
    enum: ['pending', 'in_escrow', 'released', 'refunded', 'disputed'],
    default: 'pending'
  },
  paymentMethod: {
    type: String,
    enum: ['credit_card', 'bank_transfer', 'paypal'],
    required: true
  },
  transactionId: {
    type: String
  },
  description: {
    type: String
  },
  releaseDate: {
    type: Date
  },
  dispute: {
    isDisputed: {
      type: Boolean,
      default: false
    },
    reason: {
      type: String
    },
    status: {
      type: String,
      enum: ['pending', 'resolved'],
      default: 'pending'
    },
    resolution: {
      type: String
    }
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Payment', PaymentSchema);
