const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const UserSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
  password: {
    type: String,
    required: true,
    minlength: 6
  },
  name: {
    type: String,
    required: true,
    trim: true
  },
  userType: {
    type: String,
    enum: ['freelancer', 'client'],
    required: true
  },
  profilePicture: {
    type: String,
    default: ''
  },
  joinDate: {
    type: Date,
    default: Date.now
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  contactInfo: {
    phone: {
      type: String,
      default: ''
    },
    address: {
      type: String,
      default: ''
    }
  },
  paymentInfo: {
    paymentMethods: [
      {
        type: {
          type: String,
          enum: ['card', 'bank_account', 'paypal']
        },
        details: {
          type: Object
        },
        isDefault: {
          type: Boolean,
          default: false
        }
      }
    ],
    billingAddress: {
      type: String,
      default: ''
    }
  },
  freelancerProfile: {
    skills: [String],
    portfolio: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Project'
    }],
    experience: {
      type: String,
      default: ''
    },
    hourlyRate: {
      type: Number,
      default: 0
    },
    availability: {
      type: String,
      enum: ['available', 'limited', 'unavailable'],
      default: 'available'
    },
    completedProjects: {
      type: Number,
      default: 0
    },
    rating: {
      type: Number,
      default: 0
    },
    reviews: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Review'
    }]
  },
  clientProfile: {
    company: {
      type: String,
      default: ''
    },
    industry: {
      type: String,
      default: ''
    },
    postedProjects: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Project'
    }],
    completedProjects: {
      type: Number,
      default: 0
    },
    rating: {
      type: Number,
      default: 0
    },
    reviews: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Review'
    }]
  }
}, {
  timestamps: true
});

// Hash password before saving
UserSchema.pre('save', async function(next) {
  if (!this.isModified('password')) {
    return next();
  }
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Method to compare passwords
UserSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Method to generate JWT token
UserSchema.methods.generateAuthToken = function() {
  return jwt.sign(
    { id: this._id, userType: this.userType },
    process.env.JWT_SECRET || 'designconnect_secret',
    { expiresIn: '7d' }
  );
};

module.exports = mongoose.model('User', UserSchema);
