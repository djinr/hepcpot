const jwt = require('jsonwebtoken');
const User = require('../models/user.model');

// Middleware to authenticate user with JWT
const auth = async (req, res, next) => {
  try {
    // Get token from header
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ success: false, message: 'No authentication token, access denied' });
    }
    
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'designconnect_secret');
    
    // Find user by id
    const user = await User.findById(decoded.id).select('-password');
    
    if (!user) {
      return res.status(401).json({ success: false, message: 'Token is invalid or user does not exist' });
    }
    
    // Add user to request object
    req.user = user;
    next();
  } catch (error) {
    console.error('Auth middleware error:', error.message);
    res.status(401).json({ success: false, message: 'Token is invalid or expired' });
  }
};

// Middleware to check if user is a client
const isClient = (req, res, next) => {
  if (req.user.userType !== 'client') {
    return res.status(403).json({ success: false, message: 'Access denied. Client role required.' });
  }
  next();
};

// Middleware to check if user is a freelancer
const isFreelancer = (req, res, next) => {
  if (req.user.userType !== 'freelancer') {
    return res.status(403).json({ success: false, message: 'Access denied. Freelancer role required.' });
  }
  next();
};

// Middleware to check if user is either the client or freelancer for a project
const isProjectParticipant = async (req, res, next) => {
  try {
    const projectId = req.params.id;
    const Project = require('../models/project.model');
    
    const project = await Project.findById(projectId);
    
    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }
    
    const userId = req.user._id.toString();
    const isClient = project.clientId.toString() === userId;
    const isFreelancer = project.selectedFreelancer && project.selectedFreelancer.toString() === userId;
    
    if (!isClient && !isFreelancer) {
      return res.status(403).json({ success: false, message: 'Access denied. You are not a participant in this project.' });
    }
    
    req.project = project;
    next();
  } catch (error) {
    console.error('Project participant check error:', error.message);
    res.status(500).json({ success: false, message: 'Server error' });
  }
};

module.exports = { auth, isClient, isFreelancer, isProjectParticipant };
