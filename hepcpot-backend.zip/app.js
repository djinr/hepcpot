const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const { createDemoAccounts } = require('./utils/demo-accounts');

// Load environment variables
dotenv.config();

// Initialize Express app
const app = express();

// Middleware
app.use(cors({
  origin: '*', // Allow all origins for demo purposes
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Import routes
const authRoutes = require('./routes/auth.routes');
const userRoutes = require('./routes/user.routes');
const projectRoutes = require('./routes/project.routes');
const contractRoutes = require('./routes/contract.routes');
const paymentRoutes = require('./routes/payment.routes');
const moodboardRoutes = require('./routes/moodboard.routes');
const messageRoutes = require('./routes/message.routes');

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/contracts', contractRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/moodboards', moodboardRoutes);
app.use('/api/messages', messageRoutes);

// Root route for API health check
app.get('/', (req, res) => {
  res.json({
    message: 'Welcome to Hepcpot API',
    status: 'online',
    version: '1.0.0'
  });
});

// Database connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb+srv://hepcpot:hepcpot123@cluster0.mongodb.net/hepcpot', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => {
  console.log('MongoDB connected');
  // Create demo accounts
  createDemoAccounts()
    .then(accounts => {
      console.log('Demo accounts created successfully:');
      console.log(`Client: ${accounts.clientEmail}`);
      console.log(`Freelancer: ${accounts.freelancerEmail}`);
      console.log(`Password for both: ${accounts.password}`);
    })
    .catch(err => console.error('Error creating demo accounts:', err));
})
.catch(err => console.error('MongoDB connection error:', err));

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = app;
