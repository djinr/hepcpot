const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/user.model');
const Project = require('../models/project.model');
const Contract = require('../models/contract.model');
const Payment = require('../models/payment.model');
const Message = require('../models/message.model');

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/hepcpot', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected for demo accounts'))
.catch(err => console.error('MongoDB connection error:', err));

// Create demo accounts
const createDemoAccounts = async () => {
  try {
    // Check if demo accounts already exist
    const clientExists = await User.findOne({ email: 'democlient@hepcpot.com' });
    const freelancerExists = await User.findOne({ email: 'demofreelancer@hepcpot.com' });
    
    if (clientExists && freelancerExists) {
      console.log('Demo accounts already exist');
      return {
        clientId: clientExists._id,
        freelancerId: freelancerExists._id,
        clientEmail: 'democlient@hepcpot.com',
        freelancerEmail: 'demofreelancer@hepcpot.com',
        password: 'Demo123!'
      };
    }
    
    // Create client user
    const clientUser = await User.create({
      name: 'Demo Client',
      email: 'democlient@hepcpot.com',
      password: await bcrypt.hash('Demo123!', 10),
      userType: 'client',
      profilePicture: 'https://via.placeholder.com/150',
      isVerified: true,
      contactInfo: {
        phone: '555-123-4567',
        address: '123 Client St, Business City'
      },
      clientProfile: {
        company: 'Demo Company',
        industry: 'Technology'
      }
    });
    
    // Create freelancer user
    const freelancerUser = await User.create({
      name: 'Demo Designer',
      email: 'demofreelancer@hepcpot.com',
      password: await bcrypt.hash('Demo123!', 10),
      userType: 'freelancer',
      profilePicture: 'https://via.placeholder.com/150',
      isVerified: true,
      contactInfo: {
        phone: '555-987-6543',
        address: '456 Designer Ave, Creative City'
      },
      freelancerProfile: {
        skills: ['Logo Design', 'Branding', 'Web Design', 'Illustration'],
        experience: '5+ years of experience in graphic design and branding',
        hourlyRate: 75,
        availability: 'available',
        rating: 4.8
      }
    });
    
    // Create demo project
    const project = await Project.create({
      title: 'Demo Project: Brand Identity Design',
      description: 'This is a demo project for a complete brand identity package including logo, color palette, typography, and basic brand guidelines.',
      clientId: clientUser._id,
      category: 'branding',
      subcategory: 'tech',
      status: 'in_progress',
      budget: {
        minAmount: 1500,
        maxAmount: 3000,
        type: 'fixed'
      },
      timeline: {
        postedDate: new Date(),
        deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
      },
      proposals: [{
        freelancerId: freelancerUser._id,
        proposalText: 'I would love to work on your brand identity project. With my experience in tech branding, I can deliver a modern and impactful identity that will help your startup stand out.',
        bidAmount: 2500,
        estimatedTime: '3 weeks',
        status: 'accepted',
        submissionDate: new Date()
      }],
      selectedFreelancer: freelancerUser._id,
      milestones: [
        {
          title: 'Logo Design',
          description: 'Create 3-5 logo concepts and refine the selected option',
          amount: 1000,
          dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000), // 10 days from now
          status: 'in_progress'
        },
        {
          title: 'Color Palette & Typography',
          description: 'Develop color palette and typography system',
          amount: 750,
          dueDate: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000), // 20 days from now
          status: 'pending'
        },
        {
          title: 'Brand Guidelines',
          description: 'Create comprehensive brand guidelines document',
          amount: 750,
          dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
          status: 'pending'
        }
      ],
      moodboard: {
        elements: [
          {
            type: 'image',
            content: 'https://via.placeholder.com/500x300',
            notes: 'Modern tech aesthetic with clean lines',
            addedBy: clientUser._id,
            addedDate: new Date()
          },
          {
            type: 'color',
            content: '#4e57ef',
            notes: 'Primary blue - energetic and trustworthy',
            addedBy: freelancerUser._id,
            addedDate: new Date()
          },
          {
            type: 'text',
            content: 'Sans-serif typography with geometric influence',
            notes: 'For a modern, tech-forward look',
            addedBy: freelancerUser._id,
            addedDate: new Date()
          }
        ],
        isPublic: false
      }
    });
    
    // Update user profiles with project
    await User.findByIdAndUpdate(clientUser._id, {
      $push: { 'clientProfile.postedProjects': project._id }
    });
    
    await User.findByIdAndUpdate(freelancerUser._id, {
      $push: { 'freelancerProfile.portfolio': project._id }
    });
    
    // Create contract
    const contract = await Contract.create({
      projectId: project._id,
      clientId: clientUser._id,
      freelancerId: freelancerUser._id,
      title: `Contract for ${project.title}`,
      description: project.description,
      terms: 'This agreement outlines the working relationship between the client and freelancer for the specified project.',
      scope: 'Complete brand identity package including logo, color palette, typography, and basic brand guidelines.',
      deliverables: [
        'Logo in multiple formats (PNG, SVG, PDF)',
        'Color palette with hex codes',
        'Typography specifications',
        'Brand guidelines PDF'
      ],
      timeline: {
        startDate: new Date(),
        endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
        milestones: [
          {
            title: 'Logo Design',
            dueDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000) // 10 days from now
          },
          {
            title: 'Color Palette & Typography',
            dueDate: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000) // 20 days from now
          },
          {
            title: 'Brand Guidelines',
            dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
          }
        ]
      },
      payment: {
        amount: 2500,
        type: 'fixed',
        currency: 'USD',
        milestones: [
          {
            title: 'Logo Design',
            amount: 1000,
            releaseCondition: 'Upon client approval of final logo design'
          },
          {
            title: 'Color Palette & Typography',
            amount: 750,
            releaseCondition: 'Upon client approval of color palette and typography'
          },
          {
            title: 'Brand Guidelines',
            amount: 750,
            releaseCondition: 'Upon client approval of brand guidelines document'
          }
        ]
      },
      signatures: {
        client: {
          signed: true,
          date: new Date()
        },
        freelancer: {
          signed: true,
          date: new Date()
        }
      },
      status: 'active'
    });
    
    // Update project with contract
    await Project.findByIdAndUpdate(project._id, {
      'contract.contractId': contract._id,
      'contract.signedByClient': true,
      'contract.signedByFreelancer': true,
      'contract.signatureDate': new Date()
    });
    
    // Create payment
    await Payment.create({
      projectId: project._id,
      contractId: contract._id,
      milestoneId: project.milestones[0]._id,
      senderId: clientUser._id,
      recipientId: freelancerUser._id,
      amount: 1000,
      platformFee: 50,
      status: 'in_escrow',
      paymentMethod: 'credit_card',
      description: 'Payment for Logo Design milestone'
    });
    
    // Create messages
    const conversationId = [clientUser._id.toString(), freelancerUser._id.toString()].sort().join('-');
    
    await Message.create({
      conversationId,
      senderId: clientUser._id,
      recipientId: freelancerUser._id,
      projectId: project._id,
      content: 'Hi Designer, I\'m excited to work with you on our brand identity project!',
      isRead: true
    });
    
    await Message.create({
      conversationId,
      senderId: freelancerUser._id,
      recipientId: clientUser._id,
      projectId: project._id,
      content: 'Thanks! I\'m looking forward to creating a great brand identity for your company. I\'ll start working on some initial concepts right away.',
      isRead: false
    });
    
    await Message.create({
      conversationId,
      senderId: clientUser._id,
      recipientId: freelancerUser._id,
      projectId: project._id,
      content: 'That sounds great. I\'ve added some inspiration to the moodboard that might help guide the direction.',
      isRead: true
    });
    
    console.log('Demo accounts created successfully');
    
    return {
      clientId: clientUser._id,
      freelancerId: freelancerUser._id,
      clientEmail: 'democlient@hepcpot.com',
      freelancerEmail: 'demofreelancer@hepcpot.com',
      password: 'Demo123!'
    };
  } catch (error) {
    console.error('Error creating demo accounts:', error);
    throw error;
  }
};

module.exports = { createDemoAccounts };
